#!/bin/sh
BUILDDATE=`date +%m%d-%H%M`
ZIP=kdk-pie-chiron-$BUILDDATE.zip

# rm -f ./kdk-chiron-*.zip
cp -f ./android_kernel_xiaomi_msm8998/out/arch/arm64/boot/Image.gz-dtb ./zip
chmod 777 ./zip/Image.gz-dtb

cd ./zip ; zip -r ../$ZIP . * ; cd ..

rm -f ./zip/Image.gz-dtb



